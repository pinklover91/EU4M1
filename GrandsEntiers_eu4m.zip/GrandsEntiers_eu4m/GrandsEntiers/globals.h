#ifndef globals_h
#define globals_h

#define null NULL

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <conio.h>
#include <string>
#include <sstream>

using namespace std;

// Effacer ecran
void effacerEcran();

// Atendre a ce que l'utilisateur compose une touche
void attendeEcran();

// Afficher le menu principale
void afficherMenu();

#endif